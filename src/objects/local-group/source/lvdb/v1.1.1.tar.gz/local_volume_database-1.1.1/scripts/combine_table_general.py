## this takes yaml files as input and creates tables and saves them as csv (or other file types) 

import numpy as np

import astropy.table as table

from astropy import units as u
import astropy.coordinates as coord

from collections import Counter

import numpy.ma as ma
import yaml

import os

import corner

import local_volume_database as lvdb
import warnings; warnings.filterwarnings('ignore')

path = "data_input/"
dir_list = os.listdir(path)
dir_list = [i for i in dir_list if i!='readme.md']
## this is to get a list of all "key"s which should correspond to file names (+.yaml)
table_list = []
for i in range(len(dir_list)):
    with open(path+ dir_list[i], 'r') as stream:
        try:
            stream_yaml = yaml.load(stream, Loader=yaml.Loader)
            if 'table' in stream_yaml.keys():
                table_list.append(stream_yaml['table'])
            else:
                print(stream_yaml['key'], "missing table")
        except yaml.YAMLError as exc:
            print(exc)
print("all tables")
print(Counter(table_list))

## we don't use every possible column for the "standard" table
col_name_dwarf = ['name','host','confirmed_real', 'confirmed_dwarf',  'rhalf', 'rhalf_em', 'rhalf_ep', 'position_angle', 'position_angle_em', 'position_angle_ep', 'ellipticity', 'ellipticity_em', 'ellipticity_ep', 'ellipticity_ul', 'ref_structure', 'distance_modulus', 'distance_modulus_em', 'distance_modulus_ep', 'ref_distance', 'apparent_magnitude_v', 'apparent_magnitude_v_em', 'apparent_magnitude_v_ep', 'ref_m_v', 'vlos_systemic', 'vlos_systemic_em', 'vlos_systemic_ep', 'vlos_sigma', 'vlos_sigma_em', 'vlos_sigma_ep', 'vlos_sigma_ul', 'ref_vlos', 'pmra', 'pmra_em', 'pmra_ep', 'pmdec', 'pmdec_em', 'pmdec_ep', 'ref_proper_motion', 'metallicity_spectroscopic', 'metallicity_spectroscopic_em', 'metallicity_spectroscopic_ep', 'metallicity_spectroscopic_sigma', 'metallicity_spectroscopic_sigma_em', 'metallicity_spectroscopic_sigma_ep', 'metallicity_spectroscopic_sigma_ul', 'ref_metallicity_spectroscopic', 'rcore', 'rcore_em', 'rcore_ep', 'rking', 'rking_em', 'rking_ep', 'ref_structure_king', 'rad_sersic', 'rad_sersic_em', 'rad_sersic_ep', 'n_sersic', 'n_sersic_em', 'n_sersic_ep', 'ref_structure_sersic', 'age', 'age_em', 'age_ep', 'ref_age', 'metallicity_isochrone', 'metallicity_isochrone_em', 'metallicity_isochrone_ep', 'ref_metallicity_isochrone', 'flux_HI', 'flux_HI_em', 'flux_HI_ep', 'flux_HI_ul', 'ref_flux_HI']
col_type_dwarf = [ 'U100','U100','i1', 'i1','f8', 'f8', 'f8','f8', 'f8', 'f8','f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8' ,'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'f8','U100']
print(len(col_name_dwarf), len(col_type_dwarf))

col_name_gc = ['name','host','confirmed_real', 'confirmed_star_cluster',  'rhalf', 'rhalf_em', 'rhalf_ep', 'position_angle', 'position_angle_em', 'position_angle_ep', 'ellipticity', 'ellipticity_em', 'ellipticity_ep', 'ellipticity_ul', 'ref_structure', 'distance_modulus', 'distance_modulus_em', 'distance_modulus_ep', 'ref_distance', 'apparent_magnitude_v', 'apparent_magnitude_v_em', 'apparent_magnitude_v_ep', 'ref_m_v', 'vlos_systemic', 'vlos_systemic_em', 'vlos_systemic_ep', 'vlos_sigma', 'vlos_sigma_em', 'vlos_sigma_ep', 'vlos_sigma_ul', 'ref_vlos', 'pmra', 'pmra_em', 'pmra_ep', 'pmdec', 'pmdec_em', 'pmdec_ep', 'ref_proper_motion', 'metallicity_spectroscopic', 'metallicity_spectroscopic_em', 'metallicity_spectroscopic_ep', 'metallicity_spectroscopic_sigma', 'metallicity_spectroscopic_sigma_em', 'metallicity_spectroscopic_sigma_ep', 'metallicity_spectroscopic_sigma_ul', 'ref_metallicity_spectroscopic', 'rcore', 'rcore_em', 'rcore_ep', 'rking', 'rking_em', 'rking_ep', 'ref_structure_king', 'rad_sersic', 'rad_sersic_em', 'rad_sersic_ep', 'n_sersic', 'n_sersic_em', 'n_sersic_ep', 'ref_structure_sersic', 'age', 'age_em', 'age_ep', 'ref_age', 'metallicity_isochrone', 'metallicity_isochrone_em', 'metallicity_isochrone_ep', 'ref_metallicity_isochrone']
col_type_gc = [ 'U100','U100','i1', 'i1','f8', 'f8', 'f8','f8', 'f8', 'f8','f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8' ,'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'U100', 'f8', 'f8', 'f8', 'U100',]
print(len(col_name_gc), len(col_type_gc))

## create gc tables
comb_gc_ufsc = table.Table(np.zeros((Counter(table_list)['gc_ufsc']+Counter(table_list)['gc_halo']+Counter(table_list)['gc_ambiguous'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))
comb_gc_harris = table.Table(np.zeros((Counter(table_list)['gc_harris'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))
comb_gc_disk = table.Table(np.zeros((Counter(table_list)['gc_disk']+Counter(table_list)['gc_mw_new'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))
comb_gc_dwarf = table.Table(np.zeros((Counter(table_list)['gc_dwarf_hosted'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))
comb_gc_other = table.Table(np.zeros((Counter(table_list)['gc_other'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))

## add all the columns.  The columns are masked for missing entries 
# for i,j in zip(col_name_gc, col_type_gc):
## the only difference between GC and dwarf is whether HI gas columns are included.  Have empty columns is fine.
# for i,j in zip(col_name_dwarf, col_type_dwarf):
    # comb_gc_ufsc[i] = np.ma.masked_all(len(comb_gc_ufsc), dtype=j)
    # comb_gc_harris[i] = np.ma.masked_all(len(comb_gc_harris), dtype=j)
    # comb_gc_disk[i] = np.ma.masked_all(len(comb_gc_disk), dtype=j)
    # comb_gc_dwarf[i] = np.ma.masked_all(len(comb_gc_dwarf), dtype=j)

## create dwarf tables
comb_dwarf_mw = table.Table(np.zeros((Counter(table_list)['dwarf_mw'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))
comb_dwarf_m31 = table.Table(np.zeros((Counter(table_list)['dwarf_m31'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))
comb_dwarf_lf = table.Table(np.zeros((Counter(table_list)['dwarf_local_field'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))
comb_dwarf_lf_distant = table.Table(np.zeros((Counter(table_list)['dwarf_local_field_distant'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))

comb_candidate = table.Table(np.zeros((Counter(table_list)['candidate'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))
comb_host = table.Table(np.zeros((Counter(table_list)['misc'], 3)),names=('key', 'ra', 'dec' ), dtype=('U100','f8', 'f8', ))

for i,j in zip(col_name_dwarf, col_type_dwarf):
    comb_dwarf_mw[i] = np.ma.masked_all(len(comb_dwarf_mw), dtype=j)
    comb_dwarf_m31[i] = np.ma.masked_all(len(comb_dwarf_m31), dtype=j)
    comb_dwarf_lf[i] = np.ma.masked_all(len(comb_dwarf_lf), dtype=j)
    comb_dwarf_lf_distant[i] = np.ma.masked_all(len(comb_dwarf_lf_distant), dtype=j)

    comb_gc_ufsc[i] = np.ma.masked_all(len(comb_gc_ufsc), dtype=j)
    comb_gc_harris[i] = np.ma.masked_all(len(comb_gc_harris), dtype=j)
    comb_gc_disk[i] = np.ma.masked_all(len(comb_gc_disk), dtype=j)
    comb_gc_dwarf[i] = np.ma.masked_all(len(comb_gc_dwarf), dtype=j)

    comb_candidate[i] = np.ma.masked_all(len(comb_candidate), dtype=j)
    comb_host[i] = np.ma.masked_all(len(comb_host), dtype=j)
    comb_gc_other[i] = np.ma.masked_all(len(comb_gc_other), dtype=j)

## distance modulus
def dist_mod(mu, mu_em=0, mu_ep=0):
    def dm(x):
        return pow(10., x/5.+1.)/1000.
    return dm(mu), dm(mu)-dm(mu-mu_em), dm(mu+mu_ep)-dm(mu)

def add_to_table(yaml_input, table_output, place, ):
    ## this function add input to tables
    missing_key=[]
    table_output['key'][place] = yaml_input['key']
    table_output['ra'][place] = yaml_input['location']['ra']
    table_output['dec'][place] = yaml_input['location']['dec']
    for y in ['structure', 'distance','m_v', 'velocity', 'proper_motion', 'metallicity_spectroscopic', 'structure_king', 'structure_sersic', 'age', 'metallicity_isochrone', 'flux_HI', 'name_discovery']:
        if y in yaml_input.keys():
            x = list(yaml_input[y].keys())
            ## special case of distance fixed to the value in another file (ie host)
            if y == 'distance' and 'distance_fixed_host' in x and stream_yaml['name_discovery']['host'] + '.yaml' in dir_list:
                try:
                # if True:
                    # print("host missing for", stream_yaml['key'], path + stream_yaml['name_discovery']['host'] + '.yaml')
                    with open(path + stream_yaml['name_discovery']['host'] + '.yaml', 'r') as yaml_to_load:
                        stream_yaml_host = yaml.load(yaml_to_load, Loader=yaml.Loader)
                        # print("stream_yaml_host", stream_yaml_host)
                        x = list(stream_yaml_host['distance'].keys())
                        if 'distance_fixed_host' in stream_yaml_host['distance'].keys() and 'host' in stream_yaml_host['name_discovery']:
                                with open(path + stream_yaml_host['name_discovery']['host'] + '.yaml', 'r') as yaml_to_load_level_two:
                                    stream_yaml_host_level_two = yaml.load(yaml_to_load_level_two, Loader=yaml.Loader)
                                    x2 = list(stream_yaml_host_level_two['distance'].keys())
                                    for list_key in range(len(x2)):
                                        name = x2[list_key]
                                        if name not in table_output.dtype.names:
                                            missing_key.append(name)
                                            continue
                                        else:
                                            table_output[name][place] = stream_yaml_host_level_two['distance'][x2[list_key]]
                        else:
                            for list_key in range(len(x)):
                                name = x[list_key]
                                if name not in table_output.dtype.names:
                                    missing_key.append(name)
                                    continue
                                else:
                                    table_output[name][place] = stream_yaml_host['distance'][x[list_key]]
                except:
                    print("host missing for", stream_yaml['key'])
                        # print(stream_yaml['name_discovery']['host'] + '.yaml' in dir_list)
                # continue
            ## dealing with units 
            elif y in ['structure', 'structure_king', 'structure_sersic'] and 'spatial_units' in x:
                unit_conversion = 1.
                if yaml_input[y]['spatial_units'].replace(' ', '') =='arcsec':
                    unit_conversion = 1./60. ## convert from arcsec to arcmin
                    # print(yaml_input['key'], unit_conversion)
                for list_key in range(len(x)):
                    name = x[list_key]
                    
                    if name not in table_output.dtype.names:
                        missing_key.append(name)
                        continue
                    else:
                        if name in ['rcore', 'rcore_em', 'rcore_ep', 'rking', 'rking_em', 'rking_ep',  'rad_sersic', 'rad_sersic_em', 'rad_sersic_ep','rhalf', 'rhalf_em', 'rhalf_ep']:
                            table_output[name][place] = yaml_input[y][x[list_key]] * unit_conversion
                            # print(name, yaml_input['key'])
                        else:
                            table_output[name][place] = yaml_input[y][x[list_key]]
            ## everything else
            else:
                x = list(yaml_input[y].keys())
                for list_key in range(len(x)):
                    name = x[list_key]
                    if name not in table_output.dtype.names:
                        missing_key.append(name)
                        continue
                    else:
                        table_output[name][place] = yaml_input[y][x[list_key]]
    return missing_key

def value_add(input_table, table_type='dwarf', **kwargs):
    np.random.seed(1988) ## so each monte carlo is the same if nothing is changed
    spatial_units = kwargs.get("spatial_units", "arcmin")
    spatial_units_conversion = 60.
    if spatial_units == 'arcsec':
        spatial_units_conversion = 3600.
    ## value added columns
    input_table['M_V'] = input_table['apparent_magnitude_v']-input_table['distance_modulus']
    input_table['M_V_em'] = input_table['apparent_magnitude_v_em']
    input_table['M_V_ep'] = input_table['apparent_magnitude_v_ep']

    ## stellar mass
    def lum(m_x, m_x_sun=4.83):
        return pow(10., -.4*(m_x - m_x_sun) )
    input_table['mass_stellar'] = np.log10(lum(input_table['M_V']) * 2.)

    ## heliocentric distance
    if np.ma.is_masked(input_table['distance_modulus_em']) ==True:
        d, dem, dep = dist_mod( input_table['distance_modulus'])
        input_table['distance'] = d
        input_table['distance_em'] = np.ma.masked
        input_table['distance_ep'] = np.ma.masked
    else:
        d, dem, dep = dist_mod( input_table['distance_modulus'], input_table['distance_modulus_em'], input_table['distance_modulus_ep'])
        input_table['distance'] = d
        input_table['distance_em'] = dem
        input_table['distance_ep'] = dep
    
    ## Galactic longitude and latitude
    c_table_input = coord.SkyCoord(ra=input_table['ra']*u.deg, dec=input_table['dec']*u.deg,distance=input_table['distance']*u.kpc,  frame='icrs',)
    input_table['ll'] = c_table_input.galactic.l.value
    input_table['bb'] = c_table_input.galactic.b.value
    
    ## super Galactic coordinates
    # c_test = coord.SkyCoord(ra=input_table['ra']*u.deg, dec=input_table['dec']*u.deg, distance=input_table['distance']*u.kpc,  frame='icrs',)
    comb_sg = c_table_input.transform_to(coord.Supergalactic) 
    input_table['sg_xx'] = comb_sg.cartesian.x.value
    input_table['sg_yy'] = comb_sg.cartesian.y.value
    input_table['sg_zz'] = comb_sg.cartesian.z.value
    # input_table['sg_xx'] = comb_sg.distance.value*np.cos(np.deg2rad(comb_sg.sgl.value)) * np.cos(np.deg2rad(comb_sg.sgb.value))
    # input_table['sg_yy'] = comb_sg.distance.value*np.sin(np.deg2rad(comb_sg.sgl.value)) * np.cos(np.deg2rad(comb_sg.sgb.value))
    # input_table['sg_zz'] = comb_sg.distance.value*np.sin(np.deg2rad(comb_sg.sgl.value))

    c_table_input = coord.SkyCoord(ra=input_table['ra']*u.deg, dec=input_table['dec']*u.deg,distance=input_table['distance']*u.kpc,  frame='icrs',)
    comb = c_table_input.transform_to(coord.Galactocentric) 
    ## 3D distance to Galactic center
    input_table['distance_gc'] = np.sqrt(comb.x.value**2 + comb.y.value**2 + comb.z.value**2)

    ra0_m31, dec0_m31, distance_m31 = 10.6839167, 41.26567, 776.2
    coord_m31 = coord.SkyCoord(ra=ra0_m31*u.deg, dec=dec0_m31*u.deg, distance=distance_m31*u.kpc,  frame='icrs',)
    try:
        with open(path + 'm_031' + '.yaml', 'r') as yaml_to_load:
            host_m31 = yaml.load(yaml_to_load, Loader=yaml.Loader)
            coord_m31 = coord.SkyCoord(ra=host_m31['location']['ra']*u.deg, dec=host_m31['location']['dec']*u.deg, distance=dist_mod( host_m31['distance']['distance_modulus'])[0]*u.kpc,  frame='icrs',)
    except:
        print("no M31 host info", path + 'm_031' + '.yaml')
    ## 3D distance to M31
    input_table['distance_m31'] = c_table_input.separation_3d(coord_m31)
    
    ## 3D distance to LG center, assumes mass_mw = mass_m31
    costheta = np.sin(np.deg2rad(input_table['dec'])) * np.sin(np.deg2rad(dec0_m31)) + np.cos(np.deg2rad(input_table['dec'])) * np.cos(np.deg2rad(dec0_m31)) * np.cos(np.deg2rad(input_table['ra'] - ra0_m31))
    distance_delta = distance_m31/2.
    input_table['distance_lg'] = np.sqrt(input_table['distance']**2 + distance_delta**2 - 2. * distance_delta* input_table['distance'] * costheta)

    ## 3D distance to host galaxy
    input_table['distance_host'] = np.zeros(len(input_table), dtype=float)
    for i in range(len(input_table)):
        if np.ma.is_masked(input_table['host'][i]):
            input_table['distance_host'][i] = np.ma.masked
        elif input_table['host'][i] == 'mw':
            input_table['distance_host'][i] = input_table['distance_gc'][i]
        else:
            try:
                with open(path + input_table['host'][i] + '.yaml', 'r') as yaml_to_load:
                    host_yaml = yaml.load(yaml_to_load, Loader=yaml.Loader)
                    d = dist_mod( host_yaml['distance']['distance_modulus'])[0]
                    coord_host = coord.SkyCoord(ra=host_yaml['location']['ra']*u.deg, dec=host_yaml['location']['dec']*u.deg, distance=d*u.kpc,  frame='icrs',)
                    coord_dwarf = coord.SkyCoord(ra=input_table['ra'][i]*u.deg, dec=input_table['dec'][i]*u.deg, distance=input_table['distance'][i]*u.kpc,  frame='icrs',)
                    input_table['distance_host'][i] = coord_dwarf.separation_3d(coord_host).value
            except:
                print("no  host info", input_table['key'][i], path + input_table['host'][i] + '.yaml')    

    #HI mass
    if table_type=='dwarf':
        input_table['mass_HI'] = np.log10(235600 * input_table['flux_HI']*(input_table['distance']/1000.)**2 )
        input_table['mass_HI_ul'] = np.log10(235600 * input_table['flux_HI_ul']*(input_table['distance']/1000.)**2 )
    
    input_table['metallicity'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['metallicity_em'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['metallicity_ep'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['metallicity_type'] = np.ma.masked_all(len(input_table), dtype='U100')
    for i in range(len(input_table)):
        if ma.is_masked(input_table['metallicity_spectroscopic'][i])==False:
            input_table['metallicity'][i] = input_table['metallicity_spectroscopic'][i]
            input_table['metallicity_em'][i] = input_table['metallicity_spectroscopic_em'][i]
            input_table['metallicity_ep'][i] = input_table['metallicity_spectroscopic_ep'][i]
            input_table['metallicity_type'][i] = 'spectroscopic'
        elif  ma.is_masked(input_table['metallicity_photometric'][i])==False:
            input_table['metallicity'][i] = input_table['metallicity_photometric'][i]
            input_table['metallicity_em'][i] = input_table['metallicity_photometric_em'][i]
            input_table['metallicity_ep'][i] = input_table['metallicity_photometric_ep'][i]
            input_table['metallicity_type'][i] = 'photometric'
        elif  ma.is_masked(input_table['metallicity_isochrone'][i])==False:
            input_table['metallicity'][i] = input_table['metallicity_isochrone'][i]
            input_table['metallicity_em'][i] = input_table['metallicity_isochrone_em'][i]
            input_table['metallicity_ep'][i] = input_table['metallicity_isochrone_ep'][i]
            input_table['metallicity_type'][i] = 'isochrone'
    
    # radial velocity in Galactic standard of rest https://docs.astropy.org/en/stable/generated/examples/coordinates/rv-to-gsr.html
    c_table_input = coord.SkyCoord(ra=input_table['ra']*u.deg, dec=input_table['dec']*u.deg,distance=input_table['distance']*u.kpc,radial_velocity=input_table['vlos_systemic']*u.km/u.s,  frame='icrs',)
    coord.galactocentric_frame_defaults.set("latest")
    v_sun = coord.Galactocentric().galcen_v_sun.to_cartesian()

    gal = c_table_input.transform_to(coord.Galactic)
    cart_data = gal.data.to_cartesian()
    unit_vector = cart_data / cart_data.norm()

    v_proj = v_sun.dot(unit_vector)
    vgsr = c_table_input.radial_velocity + v_proj
    vel_lg, angle_lg_l, angle_lg_b = 316, 93, -4
    input_table['velocity_gsr'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['velocity_lg'] = np.ma.masked_all(len(input_table), dtype=float)
    for i in range(len(input_table)):
        if ma.is_masked(input_table['vlos_systemic'][i])==False:
            input_table['velocity_gsr'][i] = vgsr[i].value
            input_table['velocity_lg'][i] = input_table['vlos_systemic'][i] + vel_lg * (np.sin(np.deg2rad(input_table['bb'][i])) * np.sin(np.deg2rad(angle_lg_b)) + np.cos(np.deg2rad(input_table['bb'][i])) * np.cos(np.deg2rad(angle_lg_b)) * np.cos(np.deg2rad(input_table['ll'][i] - angle_lg_l)))
        
    input_table['mass_dynamical_wolf'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['mass_dynamical_wolf_em'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['mass_dynamical_wolf_ep'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['mass_dynamical_wolf_ul'] = np.ma.masked_all(len(input_table), dtype=float)

    input_table['rhalf_physical'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['rhalf_physical_em'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['rhalf_physical_ep'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['rhalf_sph_physical'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['rhalf_sph_physical_em'] = np.ma.masked_all(len(input_table), dtype=float)
    input_table['rhalf_sph_physical_ep'] = np.ma.masked_all(len(input_table), dtype=float)

    input_table['surface_brightness_rhalf'] = np.ma.masked_all(len(input_table), dtype=float)

    for i in range(len(input_table)):
        y= lvdb.compute_mass_error(input_table['rhalf'][i], input_table['rhalf_em'][i], input_table['rhalf_ep'][i], input_table['ellipticity'][i], input_table['ellipticity_em'][i], input_table['ellipticity_ep'][i], input_table['distance'][i], input_table['distance_em'][i], input_table['distance_ep'][i],input_table['vlos_sigma'][i], input_table['vlos_sigma_em'][i], input_table['vlos_sigma_ep'][i], seed=1988)

        input_table['mass_dynamical_wolf'][i] = y[0]
        input_table['mass_dynamical_wolf_em'][i] = y[1]
        input_table['mass_dynamical_wolf_ep'][i] = y[2]
        
        z= lvdb.compute_mass_error(input_table['rhalf'][i], input_table['rhalf_em'][i], input_table['rhalf_ep'][i], input_table['ellipticity'][i], input_table['ellipticity_em'][i], input_table['ellipticity_ep'][i], input_table['distance'][i], input_table['distance_em'][i], input_table['distance_ep'][i],input_table['vlos_sigma_ul'][i], np.ma.masked, np.ma.masked, seed=1988)
        input_table['mass_dynamical_wolf_ul'][i] = z[0]

        rh_azi = lvdb.compute_rhalf_error(input_table['rhalf'][i], input_table['rhalf_em'][i], input_table['rhalf_ep'][i], input_table['ellipticity'][i], input_table['ellipticity_em'][i], input_table['ellipticity_ep'][i], input_table['distance'][i], input_table['distance_em'][i], input_table['distance_ep'][i], seed=1988)
        rh_sph = lvdb.compute_rhalf_error(input_table['rhalf'][i], input_table['rhalf_em'][i], input_table['rhalf_ep'][i], np.ma.masked, np.ma.masked, np.ma.masked, input_table['distance'][i], input_table['distance_em'][i], input_table['distance_ep'][i], seed=1988)

        input_table['rhalf_physical'][i] = rh_sph[0]
        input_table['rhalf_physical_em'][i] = rh_sph[1]
        input_table['rhalf_physical_ep'][i] = rh_sph[2]

        input_table['rhalf_sph_physical'][i] = rh_azi[0]
        input_table['rhalf_sph_physical_em'][i] = rh_azi[1]
        input_table['rhalf_sph_physical_ep'][i] = rh_azi[2]

    ## average surface brightness within half-light radius
        if ma.is_masked(input_table['rhalf_sph_physical'][i])==False:
            input_table['surface_brightness_rhalf'][i] = input_table['M_V'][i] + 19.78 + input_table['distance_modulus'][i] +  2.5 * np.log10(np.degrees(np.arctan(input_table['rhalf_sph_physical'][i]/1000./input_table['distance'][i]))**2)

    dict_round = {'M_V':2, 'M_V_em':2, 'M_V_ep':2, 'mass_stellar':2, 'distance':2, 'distance_em':2, 'distance_ep':2, 'll': 7, 'bb': 7, 'sg_xx':2, 'sg_yy':2, 'sg_zz':2, 'distance_gc':2, 'distance_m31':2, 'distance_lg':2, 'distance_host':2, 'mass_HI':2, 'mass_HI_ul':2, 'metallicity':2, 'metallicity_em':2, 'metallicity_ep':2, 'velocity_gsr':2, 'velocity_lg':2, 'mass_dynamical_wolf':2, 'mass_dynamical_wolf_em':2, 'mass_dynamical_wolf_ep':2, 'mass_dynamical_wolf_ul':2, 'rhalf_physical':2, 'rhalf_physical_em':2, 'rhalf_physical_ep':2, 'rhalf_sph_physical':2, 'rhalf_sph_physical_em':2, 'rhalf_sph_physical_ep':2, 'surface_brightness_rhalf':2 ,'rhalf':4, 'rhalf_em':4, 'rhalf_ep':4}

    for key, value in dict_round.items():
        input_table[key] = np.round(input_table[key], value)

    input_table.rename_column('confirmed_dwarf', 'confirmed_galaxy')

    lvdb.add_column(input_table, 'distance', 'distance_measurement_method', col_type='U10')
    lvdb.add_column(input_table, 'distance', 'distance_fixed_host', col_type=bool)
    # this removes distance errors from systems that are fixed at the distance of their host galaxy
    # this adds the host distance_measurement to systems that lack this column in the YAML files
    for i in range(len(input_table)):
        if input_table['distance_measurement_method'][i] == 'host':
            input_table['distance_em'][i] = np.ma.masked
            input_table['distance_ep'][i] = np.ma.masked
            input_table['distance_modulus_em'][i] = np.ma.masked
            input_table['distance_modulus_ep'][i] = np.ma.masked
            input_table['ref_distance'][i] = np.ma.masked
        elif input_table['distance_fixed_host'][i] == True:
            input_table['distance_measurement_method'][i] = 'host'
            input_table['distance_em'][i] = np.ma.masked
            input_table['distance_ep'][i] = np.ma.masked
            input_table['distance_modulus_em'][i] = np.ma.masked
            input_table['distance_modulus_ep'][i] = np.ma.masked
            input_table['ref_distance'][i] = np.ma.masked
    input_table.remove_column('distance_fixed_host')

    return input_table


missing_key = []
missing_table = []
missing_table_key = []
place_dwarf_mw = 0
place_dwarf_m31 = 0
place_dwarf_local_field = 0
place_dwarf_local_field_distant = 0
place_gc_harris = 0
place_gc_disk = 0
place_gc_ufsc =0 
place_gc_dwarf =0 
place_candidate =0
place_misc = 0
place_gc_other =0
example_keys= ['discovery_year', 'other_name', 'ref_discovery', 'type', 'spatial_units', 'central_surface_brightness', 'central_surface_brightness_em', 'central_surface_brightness_ep', 'false_positive', 'metallicity_isochrone_sigma', 'mean_ebv', 'king_concentration', 'king_concentration_em', 'king_concentration_ep', 'abbreviation', 'vlos_sigma_central', 'vlos_sigma_central_em', 'vlos_sigma_central_ep', 'confirmed_star_cluster', 'vlos_systemic_HI', 'vlos_systemic_HI_em', 'vlos_systemic_HI_ep', 'sigma_HI', 'sigma_HI_em', 'sigma_HI_ep', 'vrot_HI', 'vrot_HI_em', 'vrot_HI_ep', 'ref_HI_kinematics',  'metallicity_isochrone_sigma_em', 'metallicity_isochrone_sigma_ep', 'apparent_magnitude_v_ul', 'age_ll']

## this add each galaxy/star cluster to the tables. 
for i in range(len(dir_list)):
    with open(path+ dir_list[i], 'r') as stream:
        stream_yaml = yaml.load(stream, Loader=yaml.Loader)
        if stream_yaml['table'] == 'dwarf_mw':
            miss = add_to_table(stream_yaml, comb_dwarf_mw, place_dwarf_mw)
            place_dwarf_mw+=1
        elif stream_yaml['table'] == 'dwarf_m31':
            miss = add_to_table(stream_yaml, comb_dwarf_m31, place_dwarf_m31)
            place_dwarf_m31+=1
        elif stream_yaml['table'] == 'dwarf_local_field':
            miss = add_to_table(stream_yaml, comb_dwarf_lf, place_dwarf_local_field)
            place_dwarf_local_field+=1 
        elif stream_yaml['table'] == 'dwarf_local_field_distant':
            miss = add_to_table(stream_yaml, comb_dwarf_lf_distant, place_dwarf_local_field_distant)
            place_dwarf_local_field_distant+=1 
        elif stream_yaml['table'] == 'gc_harris':
            miss = add_to_table(stream_yaml, comb_gc_harris, place_gc_harris)
            place_gc_harris+=1
        elif stream_yaml['table'] == 'gc_disk' or stream_yaml['table'] == 'gc_mw_new':
            miss = add_to_table(stream_yaml, comb_gc_disk, place_gc_disk)
            place_gc_disk+=1 
        elif stream_yaml['table'] == 'gc_ufsc' or stream_yaml['table'] == 'gc_halo' or stream_yaml['table'] == 'gc_ambiguous':
            miss = add_to_table(stream_yaml, comb_gc_ufsc, place_gc_ufsc)
            place_gc_ufsc+=1 
        elif stream_yaml['table'] == 'gc_dwarf_hosted':
            miss = add_to_table(stream_yaml, comb_gc_dwarf, place_gc_dwarf)
            place_gc_dwarf+=1
        elif stream_yaml['table'] == 'candidate':
            miss = add_to_table(stream_yaml, comb_candidate, place_candidate)
            place_candidate+=1
        elif stream_yaml['table'] == 'misc':
            miss = add_to_table(stream_yaml, comb_host, place_misc)
            place_misc+=1 
        elif stream_yaml['table'] == 'gc_other':
            miss = add_to_table(stream_yaml, comb_gc_other, place_gc_other)
            place_gc_other+=1 
        else:
            missing_table.append(stream_yaml['table'])
            missing_table_key.append(stream_yaml['key'])
        if len(miss)>0:
            for iter in range(len(miss)):
                    if miss[iter] not in example_keys:
                        missing_key.append(miss[iter])
                        # print('extra key',stream_yaml['key'], miss)

# print("missing yaml entry", Counter(np.concatenate(missing_key).flat))
print("Tables Made")
print(Counter(missing_key).keys())
print()
missing_table = np.array(missing_table)
missing_table_key = np.array(missing_table_key)
print("missing table", Counter(missing_table))
for missing in Counter(missing_table).keys():
    temp = missing_table_key[missing_table==missing]
    print("objects missing (key)", missing, Counter(temp))

print('adding more columns')
columns_to_add = ['metallicity_photometric', 'metallicity_photometric_em', 'metallicity_photometric_ep', 'metallicity_photometric_sigma', 'metallicity_photometric_sigma_em', 'metallicity_photometric_sigma_ep', 'metallicity_photometric_sigma_ul', ]

for tab in [comb_gc_ufsc, comb_gc_harris,  comb_gc_disk, comb_gc_dwarf, comb_dwarf_mw, comb_dwarf_m31, comb_dwarf_lf, comb_dwarf_lf_distant, comb_candidate, comb_host, comb_gc_other]:
    for column in columns_to_add:
        lvdb.add_column(tab,'metallicity_photometric',column)
    lvdb.add_column(tab,'metallicity_photometric','ref_metallicity_photometric', col_type='U50')

## save output
# comb_gc_ufsc = value_add(comb_gc_ufsc, table_type='gc')
comb_gc_ufsc = value_add(comb_gc_ufsc, table_type='dwarf')

comb_gc_harris = value_add(comb_gc_harris, table_type='dwarf')
comb_gc_disk = value_add(comb_gc_disk, table_type='dwarf')
comb_gc_dwarf = value_add(comb_gc_dwarf, table_type='dwarf')

comb_dwarf_mw = value_add(comb_dwarf_mw, table_type='dwarf')
comb_dwarf_m31 = value_add(comb_dwarf_m31, table_type='dwarf')
comb_dwarf_lf = value_add(comb_dwarf_lf, table_type='dwarf')
comb_dwarf_lf_distant = value_add(comb_dwarf_lf_distant, table_type='dwarf') # , spatial_units='arcsec'

comb_candidate = value_add(comb_candidate, table_type='dwarf')
comb_host = value_add(comb_host, table_type='dwarf')

comb_gc_other = value_add(comb_gc_other, table_type='dwarf')

print("Value added columns added")

comb_dwarf_mw.sort('key')
comb_dwarf_m31.sort('key')
comb_dwarf_lf.sort('key')
comb_dwarf_lf_distant.sort('key')
comb_dwarf_mw.write('data/dwarf_mw.csv', format='csv', overwrite=True)
comb_dwarf_m31.write('data/dwarf_m31.csv', format='csv',overwrite=True)
comb_dwarf_lf.write('data/dwarf_local_field.csv', format='csv',overwrite=True)
comb_dwarf_lf_distant.write('data/dwarf_local_field_distant.csv', format='csv',overwrite=True)

comb_gc_disk.sort('key')
comb_gc_harris.sort('key')
comb_gc_ufsc.sort('key')
comb_gc_dwarf.sort('key')
comb_gc_disk.write('data/gc_mw_new.csv', format='csv',overwrite=True)
comb_gc_harris.write('data/gc_harris.csv', format='csv',overwrite=True)
comb_gc_ufsc.write('data/gc_ambiguous.csv', format='csv',overwrite=True)
comb_gc_dwarf.write('data/gc_dwarf_hosted.csv', format='csv',overwrite=True)

comb_candidate.sort('key')
comb_host.sort('key')
comb_candidate.write('data/candidate.csv', format='csv',overwrite=True)
comb_host.write('data/misc_host.csv', format='csv',overwrite=True)

comb_candidate.write('data/candidate.fits', format='fits', overwrite=True)
comb_host.write('data/misc_host.fits', format='fits', overwrite=True)

# comb_gc_ufsc.write('data/gc_ufsc.dat', format='ascii', overwrite=True)
# comb_gc_ufsc.write('data/gc_ufsc.mrt', format='ascii.mrt', overwrite=True)

comb_dwarf_mw.write('data/dwarf_mw.fits', format='fits', overwrite=True)
comb_dwarf_m31.write('data/dwarf_m31.fits', format='fits', overwrite=True)
comb_dwarf_lf.write('data/dwarf_local_field.fits', format='fits', overwrite=True)

comb_gc_disk.write('data/gc_mw_new.fits', format='fits', overwrite=True)
comb_gc_harris.write('data/gc_harris.fits', format='fits', overwrite=True)
comb_gc_ufsc.write('data/gc_ambiguous.fits', format='fits', overwrite=True)
comb_gc_dwarf.write('data/gc_dwarf_hosted.fits', format='fits', overwrite=True)

comb_dwarf = table.vstack([comb_dwarf_mw, comb_dwarf_m31, comb_dwarf_lf, comb_dwarf_lf_distant])
comb_dwarf.write('data/dwarf_all.csv', format='csv', overwrite=True)
comb_dwarf.write('data/dwarf_all.fits', format='fits', overwrite=True)


comb_gc_other.write('data/gc_other.csv', format='csv', overwrite=True)
comb_gc_other.write('data/gc_other.fits', format='fits', overwrite=True)

comb_all = table.vstack([comb_dwarf, comb_gc_harris, comb_gc_disk, comb_gc_ufsc, comb_gc_dwarf, comb_gc_other, comb_candidate, comb_host])

# lvdb.add_column(comb_all,'table','table', col_type='U50')
comb_all['table'] = np.ma.masked_all(len(comb_all), dtype='U50')
for i in range(len(comb_all)):
    k = comb_all['key'][i]
    with open(path+ k +'.yaml', 'r') as stream:
        stream_yaml = yaml.load(stream, Loader=yaml.Loader)
        comb_all['table'][i] = stream_yaml['table']
print(Counter(comb_all['table']))

lvdb.add_column(comb_all, 'name_discovery', 'confirmed_star_cluster', col_type='int')

def add_unts():
    unit_deg = ['ra', 'dec', 'position_angle', 'position_angle_em', 'position_angle_ep', 'll', 'bb',]
    unit_arcmin = ['rhalf', 'rhalf_em', 'rhalf_ep', 'rcore', 'rcore_em', 'rcore_ep', 'rking', 'rking_em', 'rking_ep',  'rad_sersic', 'rad_sersic_em', 'rad_sersic_ep']
    unit_mag = ['distance_modulus', 'distance_modulus_em', 'distance_modulus_ep', 'apparent_magnitude_v', 'apparent_magnitude_v_em', 'apparent_magnitude_v_ep', 'M_V', 'M_V_em', 'M_V_ep']
    unit_km_s = ['vlos_systemic', 'vlos_systemic_em', 'vlos_systemic_ep', 'vlos_sigma', 'vlos_sigma_em', 'vlos_sigma_ep', 'vlos_sigma_ul', 'velocity_gsr', 'velocity_lg']
    unit_mas_yr = ['pmra', 'pmra_em', 'pmra_ep', 'pmdec', 'pmdec_em', 'pmdec_ep',]
    # unit_dex = ['metallicity_spectroscopic', 'metallicity_spectroscopic_em', 'metallicity_spectroscopic_ep', 'metallicity_spectroscopic_sigma', 'metallicity_spectroscopic_sigma_em', 'metallicity_spectroscopic_sigma_ep', 'metallicity_spectroscopic_sigma_ul', 'metallicity_isochrone', 'metallicity_isochrone_em', 'metallicity_isochrone_ep', 'metallicity_photometric', 'metallicity_photometric_em', 'metallicity_photometric_ep', 'metallicity_photometric_sigma', 'metallicity_photometric_sigma_em', 'metallicity_photometric_sigma_ep', 'metallicity_photometric_sigma_ul', 'metallicity', 'metallicity_em', 'metallicity_ep']
    unit_dex = []
    unit_kpc = ['distance', 'distance_em', 'distance_ep', 'distance_gc', 'distance_m31', 'distance_lg', 'distance_host','sg_xx', 'sg_yy', 'sg_zz']
    unit_mpc = []
    unit_pc = ['rhalf_physical', 'rhalf_physical_em', 'rhalf_physical_ep', 'rhalf_sph_physical', 'rhalf_sph_physical_em', 'rhalf_sph_physical_ep',]
    unit_mag_masarc = [ 'surface_brightness_rhalf']
    unit_gyr = ['age', 'age_em', 'age_ep']
    unit_flux = ['flux_HI', 'flux_HI_em', 'flux_HI_ep', 'flux_HI_ul']
    unit_msun = ['mass_stellar',  'mass_HI', 'mass_HI_ul',  'mass_dynamical_wolf', 'mass_dynamical_wolf_em', 'mass_dynamical_wolf_ep', 'mass_dynamical_wolf_ul', ]
    for col, unit in zip([unit_deg,unit_arcmin, unit_mag, unit_km_s, unit_mas_yr, unit_dex, unit_kpc, unit_mpc, unit_pc, unit_mag_masarc, unit_gyr, unit_flux, unit_msun], [u.deg, u.arcmin, u.mag, u.km/u.s, u.mas/u.yr, u.dex, u.kpc, u.mpc, u.pc, u.mag/u.arcsec/u.arcsec, u.Gyr, u.Jy*u.km/u.s, u.dex( u.M_sun)]):
        for i in col:
            comb_all[i].unit=  unit

add_unts()

comb_all.write('data/comb_all.csv', format='csv', overwrite=True)
comb_all.write('data/comb_all.ecsv',  overwrite=True)
comb_all.write('data/comb_all.fits', format='fits', overwrite=True)

print()
