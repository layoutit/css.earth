import {readFile,writeFile,readdir} from 'node:fs/promises';
import {asteroidPositionKm} from '../../packages/astronomy/dist/index.js';
const fixtures={};
for(const path of (await readdir('packages/astronomy/src/__fixtures__')).filter(n=>/^horizons\.asteroids-\d+\.ts$/.test(n))){
 const source=await readFile(`packages/astronomy/src/__fixtures__/${path}`,'utf8');
 Object.assign(fixtures,JSON.parse(source.split(' = ')[1].split(' as const')[0]));
}
const bodies=JSON.parse(await readFile('output/trojan-population/bodies.json'));
const report=bodies.map(b=>{
 const rows=fixtures[b.id].rows.map(row=>({jd:row.jd,errorKm:Math.hypot(...asteroidPositionKm(b.id,row.jd).map((v,i)=>v-row.position[i]))}));
 return {id:b.id,query:fixtures[b.id].query,rows,regressionGuardKm:Math.ceil(Math.max(rows[0].errorKm,rows[2].errorKm)*1.15)};
});
await writeFile('output/trojan-population/orbit-errors.json',JSON.stringify(report,null,2)+'\n');
const p='packages/astronomy/src/asteroids.test.ts';let source=await readFile(p,'utf8');
source=source.replace("'annefrank': 394, 'braille': 668 }","'annefrank': 394, 'braille': 668,\n      // Trojan additions: ceil(measured independent +/-30-day maximum * 1.15) km.\n      "+report.map(r=>`${r.id}: ${r.regressionGuardKm}`).join(', ')+' }');
await writeFile(p,source);console.log(report.map(r=>({id:r.id,epoch:r.rows[1].errorKm,maximum:Math.max(r.rows[0].errorKm,r.rows[2].errorKm),guard:r.regressionGuardKm})));
