import {spawn} from 'node:child_process';
import {readFile,writeFile,open,mkdir} from 'node:fs/promises';
const base='output/trojan-population', python='/Users/ekrof/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const ids=process.argv.slice(2).length?process.argv.slice(2):JSON.parse(await readFile(`${base}/bodies.json`)).map(b=>b.id);
async function run(command,args,path){const fd=await open(path,'w');try{await new Promise((resolve,reject)=>{const child=spawn(command,args,{stdio:['ignore',fd.fd,fd.fd],env:{...process.env,PYTHONPATH:'/tmp/cssEarth-calibrated-surfaces-python'}});child.once('error',reject);child.once('close',code=>code===0?resolve():reject(new Error(`${command} ${args.join(' ')} failed with ${code}; ${path}`)));});}finally{await fd.close();}}
for(const id of ids){
 await mkdir(`${base}/${id}`,{recursive:true});
 await run(process.execPath,['--test',`tests/objects/unit/${id}/source.test.mjs`],`${base}/${id}/unit.log`);
 await run(process.execPath,[`${base}/scalar-queries.mjs`,id],`${base}/${id}/queries.log`);
 await run(python,[`${base}/verify-scalar.py`,id],`${base}/${id}/independent.log`);
 await run(python,[`${base}/atlas-anchors.py`,id],`${base}/${id}/anchors.log`);
 await run(process.execPath,[`${base}/compare-scalars.mjs`,id],`${base}/${id}/comparison.log`);
 await run(process.execPath,[`${base}/surface-fit.mjs`,id],`${base}/${id}/fit.log`);
 await run(process.execPath,[`${base}/source-comparison.mjs`,id],`${base}/${id}/source-comparison.log`);
 console.log(id,'source, topology, scalar, decoded atlas, sampled mesh fit and comparison completed');
}
