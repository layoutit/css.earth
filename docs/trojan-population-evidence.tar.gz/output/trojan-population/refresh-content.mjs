// Reuse the shared content writer and object serializer for a text-only edit.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {prepareObjectContentAssets} from '../../tools/objects/dist/content/prepare.js';
import {writeObjectJson} from '../../tools/prepare-object-json.mjs';
const read=async path=>JSON.parse(await readFile(path));
const write=(path,value)=>writeFile(path,JSON.stringify(value,null,2)+'\n');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const {id} of await read('output/trojan-population/bodies.json')){
 const root=resolve('src/planets',id),path=`${root}/source/content/object.json`,content=await read(path);
 content.lenses.controls.find(lens=>lens.id==='shape').detail='DAMIT model';await write(path,content);
 const bytes=await readFile(path),manifest=await read(`${root}/source/manifest.json`),descriptor=await read(`${root}/object.json`);
 const document=manifest.documents.find(entry=>entry.path==='content/object.json');
 document.expectedBytes=bytes.length;document.expectedSha256=sha(bytes);
 descriptor.properties.recipe.sources.find(entry=>entry.id==='content').sha256=sha(bytes);
 await write(`${root}/source/manifest.json`,manifest);await write(`${root}/object.json`,descriptor);
 const prepared=await prepareObjectContentAssets({sourceDirectory:`${root}/source`,publicDirectory:resolve('public/scenes',id),outputDirectory:`${root}/prepared`,config:{contentPath:'content/object.json'}});
 const definition=await read(`${root}/prepared/runtime.json`),tree=JSON.stringify(definition.tree);
 await writeObjectJson(id,{...definition,controls:prepared.controls});
 assert.equal(JSON.stringify((await read(`${root}/prepared/runtime.json`)).tree),tree);
 console.log(id,'source-owned dataset detail shortened; retained geometry unchanged');
}
