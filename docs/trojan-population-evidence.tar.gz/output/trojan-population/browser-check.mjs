import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {resolve} from 'node:path';
import {chromium} from 'playwright';
import {conformanceBrowserLaunch} from '../../site/test/conformance-browser-launch.mjs';
import {OBJECTS} from '../../site/objects.mjs';
import {loadPlanetBrowserProfile} from '../../site/test/load-browser-profile.mjs';

const output=resolve('output/playwright/trojan-population');
await mkdir(output,{recursive:true});
const browser=await chromium.launch((await conformanceBrowserLaunch({evidenceDirectory:output,redirectStdio:true})).options);
const reports=[];
const freshRoot=process.env.CSSEARTH_FRESH_RUNTIME_ROOT;
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
try {
 for(const density of [1,2]) for(const {id} of JSON.parse(await readFile('output/trojan-population/bodies.json')).filter(b=>!process.argv[2]||process.argv.slice(2).includes(b.id))) {
  const lens='elevation';
  const context=await browser.newContext({viewport:{width:1440,height:1000},deviceScaleFactor:density});
  const page=await context.newPage(), errors=[], assets=new Set(),freshAssets=[];
  const manifest=JSON.parse(await readFile(`src/planets/${id}/runtime-assets.json`));
  if(freshRoot)await page.route(`**/scenes/${id}/*`,async route=>{
   const filename=new URL(route.request().url()).pathname.split('/').at(-1),pin=manifest.assets.find(a=>a.filename===filename);
   assert.ok(pin,`${id}/${filename} is in the runtime inventory`);
   const body=await readFile(resolve(freshRoot,id,filename));assert.equal(body.length,pin.bytes);assert.equal(sha(body),pin.sha256);
   freshAssets.push({filename,bytes:body.length,sha256:pin.sha256});
   await route.fulfill({status:200,contentType:'image/webp',body});
  });
  await page.routeWebSocket(url=>url.host==='127.0.0.1:4278',ws=>{const server=ws.connectToServer();server.onMessage(message=>{let packet;try{packet=JSON.parse(String(message));}catch{}if(!['update','full-reload'].includes(packet?.type))ws.send(message);});});
  page.on('console',message=>{if(message.type()==='error')errors.push(message.text());});
  page.on('pageerror',e=>errors.push(e.message));
  page.on('response',r=>{if(r.status()>=400)errors.push(`${r.status()} ${r.url()}`);if(r.url().includes(`/scenes/${id}/`))assets.add(r.url());});
  const profile=await loadPlanetBrowserProfile(OBJECTS.find(o=>o.id===id));
  await page.goto(`http://127.0.0.1:4278/${id}/`,{waitUntil:'networkidle'});
  try { await profile.waitForRuntime(page); } catch(error) { console.error(JSON.stringify({id,errors,state:await page.evaluate(()=>({ready:document.documentElement.dataset.ready,body:document.querySelector('.planet-stage')?.dataset.objectId,text:document.body.innerText.slice(-2500)}))},null,2));throw error; } await profile.pause(page);
  assert.equal(await page.locator('input[name="shadows"]').isChecked(),false);
  assert.equal(await page.locator('input[name="orbit"]').isChecked(),false);
  assert.equal(await page.locator('.planet-stage').count(),1);
  assert.equal(await page.locator('.polycss-scene').count(),1);
  const catalog=await page.locator('.planet-object-item [data-object-id]').evaluateAll(nodes=>nodes.map(node=>node.dataset.objectId));
  for(const body of JSON.parse(await readFile('output/trojan-population/bodies.json')))assert.ok(catalog.includes(body.id),`${body.id} has a Solar System category row`);
  const camera=await page.evaluate(id=>{const c=window[`__${id}`].camera.state();return {controlPitch:c.controlPitch,controlYaw:c.controlYaw,zoom:c.zoom};},id);
  await profile.setCamera(page,camera);
  await page.screenshot({path:resolve(output,`${id}-dpr${density}-shape.png`)});
  await page.evaluate(()=>document.querySelector('input[name="shadows"]').click());
  await profile.stable(page);await page.waitForLoadState('networkidle');
  await page.screenshot({path:resolve(output,`${id}-dpr${density}-shape-shadows.png`)});
  await page.evaluate(()=>document.querySelector('input[name="shadows"]').click());
  await profile.selectLens(page,lens);
  assert.equal((await profile.lens(page)).id,lens);
  assert.equal(await profile.visibleLens(page),lens);
  assert.equal(await profile.pressedLens(page),lens);
  await profile.stable(page);
  assert.equal(await page.locator('astro-error-overlay').count(),0,'No development error overlay');
  const leaves=await page.locator('.planet-stage u[data-polycss-texture-leaf-sizing="raster"]').count();
  assert.equal(leaves,800);
  const selectedDensity=await profile.selectedDensity(page);
  assert.equal(selectedDensity,2);
  await page.screenshot({path:resolve(output,`${id}-dpr${density}-new-view.png`)});
  if(density===1) {
   for(const offset of [90,180,270]) {
    await profile.setCamera(page,{...camera,controlYaw:camera.controlYaw+offset});
    await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
    await page.screenshot({path:resolve(output,`${id}-yaw${offset}.png`)});
   }
  }
  await page.evaluate(()=>document.querySelector('input[name="shadows"]').click());
  await profile.stable(page);
  await page.screenshot({path:resolve(output,`${id}-dpr${density}-shadow-enabled.png`)});
  await page.evaluate(()=>document.querySelector('input[name="shadows"]').click());
  await profile.selectLens(page,profile.objectControls.lenses.defaultLens);
  await profile.selectLens(page,lens);
  await profile.stable(page);
  assert.equal(await page.locator('input[name="shadows"]').isChecked(),false);
  assert.deepEqual(errors,[]);
  const provenance=[];
  for(const path of ['object.json','prepared/object.json','prepared/runtime.json','runtime-assets.json']) {
   const bytes=await readFile(resolve('src/planets',id,path));
   provenance.push({path,sha256:createHash('sha256').update(bytes).digest('hex')});
  }
  reports.push({id,density,freshRoot:freshRoot??null,freshAssets,leaves,selectedDensity,shadowsDefault:false,camera,retained:await profile.retainedReport(page),assets:[...assets],errors,provenance});
  if(id==='diomedes'&&density===1){
   await page.locator('.planet-sidebar-view-all').click();
   await page.locator('.planet-sidebar-search').fill('Solar System');
   await page.locator('[data-object-tab="asteroid"]').click();
   assert.equal(await page.locator('.planet-object-item:not([hidden])').count(),297);
   const visible=await page.locator('.planet-object-item:not([hidden]) [data-object-id]').evaluateAll(nodes=>nodes.map(node=>node.dataset.objectId));
   for(const body of JSON.parse(await readFile('output/trojan-population/bodies.json')))assert.ok(visible.includes(body.id));
   await page.locator('.planet-sidebar-search').fill('Mentor');
   assert.equal(await page.locator('.planet-object-item:not([hidden])').count(),1);
   await page.screenshot({path:resolve(output,'asteroid-category-search.png')});
   await page.locator('.planet-object-link[data-object-id="mentor"]').click();
   const target=await loadPlanetBrowserProfile(OBJECTS.find(object=>object.id==='mentor'));
   await target.waitForRuntime(page);await target.pause(page);await page.waitForLoadState('networkidle');
   assert.equal(await page.locator('.planet-stage').count(),1);
   assert.equal(await page.locator('.polycss-scene').count(),1);
   assert.equal(await page.locator('.planet-stage').getAttribute('data-object-id'),'mentor');
   assert.equal(await page.locator('input[name="shadows"]').isChecked(),false);
   assert.deepEqual(errors,[]);
   reports.at(-1).navigation={from:'diomedes',to:'mentor',categoryCount:297,newIdsVisible:10,search:'Mentor',singleScene:true,delivery:'assembled hash-verified preview assets'};
  }
  console.log(`PASS ${id} DPR${density}: ${leaves} raster triangles, canonical density ${selectedDensity}, retained lens switches, shadows off`);
  await context.close();
 }
} finally {
 await writeFile(resolve(output,`report-${process.argv.slice(2).join('-')||'all'}.json`),JSON.stringify({buildMode:'performance',headless:true,codeRevision:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),browser:browser.version(),reports},null,2)+'\n');
 await browser.close();
}
