from pathlib import Path
import json,hashlib,math,shutil,re,copy,subprocess
ROOT=Path('output/trojan-population'); CACHE=ROOT/'research'; BASE=Path('src/planets/dike')
def read(p):return json.loads(p.read_text())
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def pin(p):return dict(expectedBytes=p.stat().st_size,expectedSha256=hashlib.sha256(p.read_bytes()).hexdigest())
def copyto(a,b):b.parent.mkdir(parents=True,exist_ok=True);subprocess.run(["cp","-c",str(a),str(b)],check=True)
def replace(v,id,name):return json.loads(json.dumps(v,ensure_ascii=False).replace('dike',id).replace('Dike',name))
bodies=read(ROOT/'bodies.json'); source_ids=set(re.findall(r'object\("([^"\n]+)"',Path('site/objects.mjs').read_text()))
elements={}
for shard in Path('packages/astronomy/src/data').glob('asteroidElements-*.data.ts'):
 elements.update(json.loads(shard.read_text().split(' = ',1)[1].split(' satisfies ')[0]))
for b in bodies:
 id=b['id'];name=b['displayName'];num=b['number'];mid=b['modelId'];url=b['modelUrl']; diameter=b['diameterKm'];radius=diameter/2;scale=b['scaleKmPerSourceUnit'];shape=f'shape/model-{mid}.txt';root=Path('src/planets')/id;s=root/'source'
 assert id not in source_ids and not (root/'object.json').exists(),id
 for sub in ['preparation','reference','shape','presentation','content','stars']: (s/sub).mkdir(parents=True,exist_ok=True)
 for file in ['stars/eso0932a.tif','stars/ESO-IMAGE-LICENSE.md','stars/LICENSE.md','stars/hyg-v41-field.json','presentation/InterVariable.ttf','presentation/LICENSE.INTER-OFL']:
  original=BASE/'source'/file
  if not original.exists():original=Path('src/planets/earth/source')/file
  if not original.exists():original=Path('/Users/ekrof/fed/cssEarth/src/planets/earth/source')/file
  copyto(original,s/file)
 star=read(s/'stars/hyg-v41-field.json');star['schema']=f'css{id}-prepared-star-source@1';write(s/'stars/hyg-v41-field.json',star)
 for file in ['damit-documentation.html','neowise-selected.csv','neowise-query.txt','neowise-definitions.html','grav2012-paper.html','hanus2023-paper.html','dutra2025-paper.html']:
  copyto(CACHE/file,s/'reference'/file)
 copyto(CACHE/f'shape-{mid}.txt',s/shape);copyto(CACHE/f'model-{mid}.html',s/f'reference/model-{mid}.html')
 if b['spinUrl']:copyto(CACHE/f'spin-{mid}.txt',s/f'reference/{mid}-IAUspin.txt')
 for ref in b['references']:copyto(CACHE/ref['file'],s/'reference'/ref['file'])
 for file in ['elements','vectors']:
  cache=Path('packages/astronomy/tools/.cache/horizons')/f'asteroid-{file}-{id}.txt'
  copyto(cache,s/f'reference/horizons-{file}.txt')
 b['distanceAu']=elements[id]['elements']['semiMajorAxisKm']/149597870.7
 b['orbitalPeriodYears']=2*math.pi/elements[id]['elements']['meanMotionRadPerDay']/365.25
 authors=', '.join(ref['label'] for ref in b['references']) or 'DAMIT archive (no linked publication in this model record)'
 credit=f'DAMIT, Astronomical Institute of Charles University; {authors}; model {mid}, version {b["version"]}.'
 kind='Convex light-curve reconstruction'
 ambiguity=' An alternative pole solution remains in the archive.' if b['alternatives'] else ''
 if num==1437:
  calibration=dict(method='published-volume-equivalent-size-transfer',diameterKm=diameter,uncertaintyKm=b['uncertaintyKm'],uncertaintyKind='Doubled published volume-equivalent radius fit uncertainty; it is not a bound on local surface accuracy.',diameterSemantics='Twice the 59.4 ± 0.3 km volume-equivalent radius in Dutra et al. (2025), fitted to the same 574-vertex, 1144-facet DAMIT model.',sourceUrl='https://doi.org/10.1098/rsta.2024.0187',reference='Dutra et al. (2025), Philosophical Transactions A 383, 20240187',sourceLabel='Dutra et al. (2025), occultation fit')
  desc=f'Convex light-curve model fitted to a stellar occultation: {diameter:g} ± {b["uncertaintyKm"]:g} km volume-equivalent diameter. Grid marks unavailable imagery; rotational phase is illustrative.'
  limits='The published occultation fit uses this same 574-vertex, 1144-facet dimensionless model, refining its uniform size, pole and period. Three observed chords constrain the silhouette; this remains an inverse model, without resolved local terrain. No albedo, craters or regolith are inferred.'
 else:
  calibration=dict(method='radiometric-effective-diameter-transfer',diameterKm=diameter,uncertaintyKm=b['uncertaintyKm'],reportedUncertaintyKm=b['uncertaintyKm'],uncertaintyKind='Quoted NEOWISE thermal-fit error; additional shape, spin and thermal-model systematics are not included in this number.',diameterSemantics='NEOWISE best-fit effective spherical diameter, transferred approximately to mesh volume diameter.',sourceUrl='https://irsa.ipac.caltech.edu/data/WISE/NEOWISE_SB/gator_docs/neowisesbprop_colDescriptions.html',reference='Grav et al. (2012), ApJ 759, 49, NEOWISE v2 row Gr12b',sourceLabel='NEOWISE v2 · Grav et al. (2012)',catalog=b['neowise'])
  desc=f'{kind} with approximate thermal size: {diameter:g} km effective diameter (fit ±{b["uncertaintyKm"]:g} km; additional shape and thermal-model uncertainty).{ambiguity} Thermal size is used as a volume-scale approximation; grid marks unavailable imagery.'
  limits='Disk-integrated NEOWISE thermal flux constrains an effective spherical diameter, not this mesh volume or a surface map. Transferring that diameter uniformly to mesh volume is approximate. The quoted fit error is not a total uncertainty and does not measure local shape accuracy. Absolute rotational phase is illustrative.'
 calibration.update(scaleKmPerSourceUnit=scale,metersPerSourceUnit=scale*1000,limitations=limits,visibleDescription=desc)
 write(s/'reference/calibration.json',calibration)
 model={**b,'sourceFields':b['fields'],'originalUnits':'dimensionless uncalibrated DAMIT coordinates'}
 write(s/'reference/damit-model.json',model)
 low,high=[v*scale-radius for v in b['radialRangeSourceUnits']];step=10**math.floor(math.log10(max(abs(low),abs(high))))
 extent=math.ceil(max(abs(low),abs(high))/step)*step
 config=replace(read(BASE/'source/preparation/terrestrial.json'),id,name)
 config['distanceAu']=b['distanceAu'];config['geometry']['radiusKm']=radius
 config['geometry']['camera']['framingScale']=min(1,radius/(b['radialRangeSourceUnits'][1]*scale))
 grid=dict(metersPerUnit=scale*1000,expectedVertices=b['vertices'],expectedFaces=b['faces'],indexBase=1)
 radial=config['geometry']['radialTerrain'];radial.update(path=shape,grid=grid);radial['simplification']['maximumErrorMeters']=diameter*10
 scientific=config['raster']['scientific'][0];scientific.update(path=shape,grid=grid,minimum=-extent,maximum=extent,valueTransform=dict(scale=.001,offset=-radius))
 scientific['relief']['referenceRadiusMeters']=radius*1000;scientific['surfaceSampling']['maximumDistanceMeters']=diameter*10
 config['celestial']['sunSource']=f'DAMIT model {mid} pole and period with JPL Horizons fixed-epoch heliocentric elements. Absolute body phase is illustrative.'
 write(s/'preparation/terrestrial.json',config)
 lam,beta,obl=map(math.radians,[b['lambda'],b['beta'],23.439291111]);eq=[math.cos(beta)*math.cos(lam),math.cos(beta)*math.sin(lam)*math.cos(obl)-math.sin(beta)*math.sin(obl),math.cos(beta)*math.sin(lam)*math.sin(obl)+math.sin(beta)*math.cos(obl)]
 rotation=read(BASE/'source/preparation/rotation.json');rotation.update(rightAscensionDegrees=math.degrees(math.atan2(eq[1],eq[0])),declinationDegrees=math.degrees(math.asin(eq[2])),periodHours=b['periodHours'],source=f'DAMIT model {mid}, version {b["version"]}: ecliptic J2000 pole ({b["lambda"]:g}, {b["beta"]:g}) degrees and sidereal period {b["periodHours"]:g} h. Equatorial conversion uses obliquity 23.439291111 degrees. Absolute phase is arbitrary.' + (' Pole and period refined by Dutra et al. (2025), Tables 5–6, for this same source model.' if num==1437 else ''))
 write(s/'preparation/rotation.json',rotation)
 content=replace(read(BASE/'source/content/object.json'),id,name);content.pop('title')
 content['panel']['introduction']=f'Jupiter Trojan in the {b["camp"]} {"leading" if b["camp"]=="L4" else "trailing"} cloud. '+kind+'. The grid marks unavailable surface imagery.'
 facts=content['panel']['facts'];facts[0].update(value=f'{radius:g} km ({"size-calibrated model" if b["calibrated"] else "approximate thermal scale"})');facts[0]['source'].update(url=calibration['sourceUrl'],label=calibration['sourceLabel'],checked='2026-09-09')
 facts[1]['value']=f'{b["distanceAu"]:.3f} AU';facts[2]['value']=f'{b["orbitalPeriodYears"]:.2f} years';facts[3]['value']=f'{b["periodHours"]:g} hours';facts[3]['source'].update(url=url,label=f'DAMIT model {mid}',checked='2026-09-09')
 if num==1437:facts[3]['source'].update(url=calibration['sourceUrl'],label='Dutra et al. (2025), same-model spin refinement')
 for fact in facts[1:3]:fact['source']=dict(url=elements[id]['query'],label='JPL Horizons, 2026-09-03 epoch',checked='2026-09-09',path='source/reference/horizons-elements.txt')
 shape_control,elev=content['lenses']['controls'];shape_control.update(description=desc,title=f'{name} · DAMIT {mid} convex shape',detail='DAMIT model')
 elevdesc=f'Radius on the shape model minus a {radius:g} km reference sphere, in false color. Heights inherit the size uncertainty; this is not independent topography or gravitational height.'
 elev.update(description=elevdesc,title=f'{name} · source-model radial height');elev['legend'].update(labels=[f'{-extent:g}','0',f'{extent:g}'],meta=f'km · {radius:g} km reference sphere',sourceUrl=url)
 for control in content['settings']['controls']:
  if control['name'] in ['shadows','orbit']:control['checked']=False
 content['resources']=[dict(label='Model record',role='terrain',description=f'DAMIT model {mid}, version {b["version"]}',href=url),dict(label='Size calibration',role='facts',description=calibration['sourceLabel'],href=calibration['sourceUrl']),dict(label='Rotation',role='rotation',description='Published pole and period; arbitrary display phase',href=url),content['resources'][-1]]
 content['provenance']['editorial']=dict(url=url,credit=credit);write(s/'content/object.json',content)
 props=dict(source=url,modelId=mid,modelVersion=b['version'],diameterKm=diameter,diameterInterpretation=desc,calibration=calibration,periodHours=b['periodHours'],poleEclipticJ2000Degrees=[b['lambda'],b['beta']],modelLimitations=limits,
  shape=dict(source=b['shapeUrl'],vertices=b['vertices'],faces=b['faces'],originalUnits=model['originalUnits'],metersPerUnit=scale*1000,firstVertexKm=[v*scale for v in b['firstVertex']],firstFaceZeroBased=[i-1 for i in b['firstFace']],extentsKm=[(hi-lo)*scale for lo,hi in b['extentsSourceUnits']],volumeCubicKm=b['signedVolume']*scale**3,volumeEquivalentRadiusKm=radius,radialRangeKm=[r*scale for r in b['radialRangeSourceUnits']]),elevation=[-extent,extent])
 write(s/'reference/model-properties.json',props)
 manifest=replace(read(BASE/'source/manifest.json'),id,name);manifest['documents']=[];manifest['generatedIntermediates']=[]
 manifest['inputs'][1].update(id=id+'-shape',path=shape,origin=b['shapeUrl'],credit=credit,coverage=desc+' '+limits,projection=dict(kind='body-fixed-cartesian-triangular-mesh',longitudeDirection='east',latitudeType='planetocentric',units=model['originalUnits'],metersPerUnit=scale*1000,referenceRadiusMeters=radius*1000),**pin(s/shape))
 acquisition=read(BASE/'source/preparation/acquisition.json');acquisition['operations']=acquisition['operations'][:2]+[dict(kind='download',groups=['restore','refresh'],path=shape,url=b['shapeUrl']),dict(kind='download',groups=['restore','refresh'],path='reference/neowise-selected.csv',url=(CACHE/'neowise-query.txt').read_text().strip())]
 write(s/'preparation/acquisition.json',acquisition);write(s/'manifest.json',manifest)
 # Title/context pins are finalized through their existing owners in finalize-sources.mjs.
 descriptor=replace(read(BASE/'object.json'),id,name);descriptor['properties']['recipe']['shape']['radiusKm']=radius;descriptor['properties'].pop('worldFrame',None);descriptor.pop('prepared',None);write(root/'object.json',descriptor)
 css=Path('src/renderers/css/styles')/(id+'-surfaces.css');css.write_text(Path('src/renderers/css/styles/dike-surfaces.css').read_text().replace('dike',id))
 test=Path('tests/objects/unit')/id/'source.test.mjs';expected={k:b[k] for k in ['modelId','shapeSha256','vertices','faces','firstVertex','firstFace','signedVolume','diameterKm','uncertaintyKm','lambda','beta','periodHours']};expected.update(name=name,modelVersion=b['version'])
 test.parent.mkdir(parents=True,exist_ok=True);test.write_text("import {test} from 'node:test';\nimport {assertCalibratedAsteroidSource} from '../asteroid-calibration-contract.mjs';\n\n// Original publisher-coordinate anchors and independent signed-volume intake.\nconst independentExpected = "+json.dumps(expected,indent=2)+f';\n\ntest("{name} preserves its source model and calibrated raster triangles", () => assertCalibratedAsteroidSource("{id}", independentExpected));\n')
 profile=Path('tests/objects/browser')/id/'browser-profile.mjs';profile.parent.mkdir(parents=True,exist_ok=True);profile.write_text(Path('tests/objects/browser/dike/browser-profile.mjs').read_text().replace('dike',id))
 refs='\n'.join(f'- [{r["label"]}]({r["url"]}) — original model publication record.' for r in b['references'])
 alternatives='; '.join(f'model {a["modelId"]}, pole {a["pole"]}, {a["url"]}' for a in b['alternatives']) or 'None listed for this target.'
 notes=f'''# ({num}) {b['name']}: source and interpretation

Checked 2026-09-09. {b['camp']} Jupiter Trojan. Selected DAMIT model **{mid}**, version **{b['version']}**. {credit}

## Shape, scale and orientation

{desc}

{limits}

The unmodified source has {b['vertices']} vertices and {b['faces']} triangles. Its signed tetrahedral volume is {b['signedVolume']:.17g} source units³; independent triangle-centroid divergence gives {b['independentSignedVolume']:.17g}. The existing recipe applies a uniform scale of {scale:.17g} km per source unit. No unit-volume assumption is made. Radial Elevation is source radius minus the declared {radius:g} km reference sphere, in false color; it is neither gravitational height nor independent topography.

Original +Z spin axis and +X reference meridian are retained. The selected ecliptic J2000 pole is ({b['lambda']:g}°, {b['beta']:g}°), with sidereal period {b['periodHours']:g} h. Conversion to equatorial J2000 uses obliquity 23.439291111°. Absolute phase is arbitrary and accelerated display spin is illustrative. Position uses JPL Horizons heliocentric ICRF elements at 2026-09-03 TT (TDB approximated as TT, under 2 ms).

## Source survey

- [Selected model]({url}) and [original mesh]({b['shapeUrl']}) — included without modifying original coordinates/connectivity. Convex light-curve inversion; concavities and fine relief are unresolved.
- [DAMIT documentation](https://damit.cuni.cz/pages/documentation) — coordinate units, pole, sidereal period and CC BY 4.0 terms.
{refs}
- [NEOWISE v2 definitions](https://irsa.ipac.caltech.edu/data/WISE/NEOWISE_SB/gator_docs/neowisesbprop_colDescriptions.html) and [Grav et al. (2012)](https://arxiv.org/abs/1209.1549) — selected original Gr12b catalog row has a fitted diameter (`D` in FIT_CODE); these are thermal properties, not resolved imagery. Formal fit error does not capture all thermal/shape systematics. CSV row, original query and definitions are pinned.
- [Dutra et al. (2025)](https://doi.org/10.1098/rsta.2024.0187) — {'included: same Diomedes mesh with refined size, pole and period. Original archive pole (150°, 5°) and period 24.4987 h remain recorded in damit-model.json, while the author fit drives the presentation' if num==1437 else 'Diomedes-specific occultation calibration, not transferred to this object'}.
- [Hanuš et al. (2023)](https://arxiv.org/abs/2308.05380) — population-wide source survey. Table B.3 adopts Ajax, Ilioneus, Pyrrhus, Eumelos, Lycomedes and Demodokus archive models. Table B.2 offers revised Agenor and Mentor solutions; their numerical meshes are not currently exposed by the public target query, so the pinned older archive solution is explicitly identified. Diomedes uses the more recent same-mesh occultation fit. Menelaus uses the 2022 archive model. No original shape is reconstructed from a paper figure.

No registered global reflectance mosaic was found in the selected model or thermal releases. Disk-integrated colors do not constrain a regolith map; the shared grid marks unavailable image coverage. Alternative archive solutions: {alternatives}

## Preparation

The existing source-meshoptimizer path retains source connectivity and reduces to at most 800 native PolyCSS `u` raster triangles, with 128 px raster cells. Error allowance is {diameter*10:g} m. Sampled source-fit error is qualified separately from source accuracy. Shadows and asteroid orbit visibility are off by default. Camera, navigation and shell use the generic contract. PR evidence records source comparison, runtime checks and delivery.
'''
 (root/'SOURCE.md').write_text(notes)
 (root/'NOTICE.md').write_text(f'# {name}: notices\n\n{credit}\n\nShape and derived geometry: DAMIT CC BY 4.0, https://creativecommons.org/licenses/by/4.0/. Original model: {url}.\n\nNEOWISE numerical thermal properties: NASA/IPAC IRSA; Grav et al. (2012), ApJ 759, 49. Diomedes calibration: Dutra et al. (2025), Philosophical Transactions A 383, 20240187. Credit the original publications; no press imagery is used.\n\nBackground: ESO/S. Brunier, CC BY 4.0. HYG star data: see source/stars/LICENSE.md. Inter font: SIL Open Font License 1.1.\n')
 print(id,'authored',flush=True)
write(ROOT/'bodies.json',bodies)

# Integration remains ordinary data in the established registry and astronomy table.
p=Path('packages/astronomy/src/bodies.ts');s=p.read_text();ids=[b['id'] for b in bodies]
s=re.sub(r'(export type AsteroidId = [^\n]+)',lambda m:m[0]+''.join(" | '"+id+"'" for id in ids),s)
s=re.sub(r'(export const ASTEROID_IDS: readonly AsteroidId\[\] = \[)([^\n]*)(\])',lambda m:m[1]+m[2]+''.join(", '"+id+"'" for id in ids)+m[3],s)
where=s.index("  'dike': body(");s=s[:where]+''.join(f"  '{b['id']}': body('{b['id']}', '{b['displayName']}', '{b['number']};', {b['diameterKm']/2}, 0, 'sun'),\n" for b in bodies)+s[where:];p.write_text(s)
p=Path('site/objects.mjs');s=p.read_text();imports=''.join(f'import {b["id"].replace("-", "_")}Descriptor from "../src/planets/{b["id"]}/object.json" with {{ type: "json" }};\n' for b in bodies);s=imports+s
pos=s.index('  object("dike",');entries=''
for b in bodies:
 id=b['id'];var=id.replace('-','_')+'Descriptor';name=b['displayName']
 entries+=f'  object("{id}", "{name}", "asteroid", "#aaaaaa", {b["distanceAu"]},\n    "Explore {name} in 3D with its published shape model and radial elevation.", packaged({var}), {var}.properties.worldFrame),\n\n'
s=s[:pos]+entries+s[pos:];p.write_text(s)

# The Sun owns the authored universe list; registry additions alone do not extend it.
sun=Path('src/planets/sun'); path=sun/'source/navigation/universe.json'; universe=read(path)
existing={body['id'] for body in universe['bodies']}
for b in bodies:
 if b['id'] not in existing:universe['bodies'].append(dict(id=b['id'],name=b['displayName'],color='#aaaaaa'))
write(path,universe); manifest=read(sun/'source/manifest.json'); digest=pin(path)
for row in manifest['inputs']:
 if row['path']=='navigation/universe.json':
  row.update(digest)
  if 'sha256' in row:row['sha256']=digest['expectedSha256']
write(sun/'source/manifest.json',manifest); descriptor=read(sun/'object.json')
next(row for row in descriptor['properties']['recipe']['sources'] if row['id']=='world-context')['sha256']=digest['expectedSha256']
write(sun/'object.json',descriptor)
