# Adapted from the existing main-belt evidence contact sheet helper.
from pathlib import Path
import json
from PIL import Image,ImageDraw,ImageFont
base=Path('output/trojan-population');bodies=json.loads((base/'bodies.json').read_text())
font=ImageFont.truetype('src/planets/diomedes/source/presentation/InterVariable.ttf',15)
views=[(0,35),(180,0),(0,90),(0,-90)]
for offset in range(0,len(bodies),5):
 group=bodies[offset:offset+5]
 sheet=Image.new('RGB',(1536,len(group)*222),'#111111');draw=ImageDraw.Draw(sheet)
 for row,b in enumerate(group):
  for col,(lon,lat) in enumerate(views):
   im=Image.open(base/b['id']/f'source-result-{lon}-{lat}.png').convert('RGB')
   sheet.paste(im.resize((384,192),Image.Resampling.LANCZOS),(col*384,row*222+30))
   draw.text((col*384+8,row*222+7),f"{b['displayName']}  {lon},{lat}  source | prepared",font=font,fill='white')
 sheet.save(base/f'source-comparison-sheet-{offset//5+1}.webp',quality=95)
 print(offset//5+1,sheet.size)
