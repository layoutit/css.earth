import json, subprocess, sys, time, os
from pathlib import Path
root=Path('output/trojan-population')
node='/Users/ekrof/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
ids=sys.argv[1:]
assert ids
reports=[]
for id in ids:
    assert id in {body['id'] for body in json.loads((root/'bodies.json').read_text())}
    begin=time.monotonic()
    with (root/f'{id}-bake.log').open('w') as log:
        subprocess.run([node,'--max-old-space-size=3072','tools/objects/dist/prepare-authored.js',id,'--write'],stdout=log,stderr=subprocess.STDOUT,check=True)
    with (root/f'{id}-unit.log').open('w') as log:
        subprocess.run([node,'--test',f'tests/objects/unit/{id}/source.test.mjs'],stdout=log,stderr=subprocess.STDOUT,check=True)
    manifest=json.loads(Path(f'src/planets/{id}/runtime-assets.json').read_text())
    row=dict(id=id,elapsedSeconds=round(time.monotonic()-begin,3),files=len(manifest['assets']),bytes=sum(a['bytes'] for a in manifest['assets']))
    reports.append(row)
    (root/'serial-bakes.json').write_text(json.dumps(reports,indent=2)+'\n')
    print(json.dumps(row),flush=True)
