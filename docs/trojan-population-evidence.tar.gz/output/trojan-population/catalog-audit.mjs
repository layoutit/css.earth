import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {OBJECTS} from '../../site/objects.mjs';
import {validatePlanetData,validateObjectPackageFiles} from '../../tools/object-package-contract.mjs';
const json=async path=>JSON.parse(await readFile(path));
const bodies=await json('output/trojan-population/bodies.json'),reports=[];
assert.equal(OBJECTS.length,416);assert.equal(OBJECTS.filter(o=>o.classification==='asteroid').length,297);
for(const body of bodies){
 const object=OBJECTS.find(o=>o.id===body.id),root=`src/planets/${body.id}`;
 assert.equal(object.name,body.displayName);assert.equal(object.classification,'asteroid');assert.equal(object.route,`/${body.id}/`);
 await validateObjectPackageFiles(object);const validation=await validatePlanetData(object);
 const config=await json(`${root}/source/preparation/terrestrial.json`),content=await json(`${root}/source/content/object.json`),minimaps=await json(`${root}/prepared/minimaps.json`);
 const lens=config.raster.scientific.find(l=>l.id==='elevation'),labels=content.lenses.controls.find(l=>l.id==='elevation').legend.labels;
 assert.equal(Number(labels[0]),lens.minimum);assert.equal(Number(labels.at(-1)),lens.maximum);
 assert.equal(content.lenses.defaultLens,'shape');assert.equal(content.settings.controls.find(c=>c.name==='shadows').checked,false);assert.equal(content.settings.controls.find(c=>c.name==='orbit').checked,false);
 assert.deepEqual(minimaps.images.map(i=>i.id).sort(),['elevation','shape']);assert.ok(minimaps.images.every(i=>i.width===640&&i.height===320));
 reports.push({id:body.id,...validation,minimum: lens.minimum,maximum:lens.maximum,legendMatches:true,shadowsDefault:false,minimapCount:minimaps.images.length});
}
await writeFile('output/trojan-population/catalog-audit.json',JSON.stringify({objects:OBJECTS.length,asteroids:OBJECTS.filter(o=>o.classification==='asteroid').length,reports},null,2)+'\n');
console.log(`${reports.length} packages, sources, runtime assets, registry identities, default settings and minimap/legend contracts passed`);
