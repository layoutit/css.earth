// Replay this batch's navigation composition from the pinned, merged baseline.
// Existing tile pixels are retained; new tiles use the standard marker recipe.
import {execFileSync} from 'node:child_process';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import sharp from 'sharp';
import {OBJECTS} from '../../site/objects.mjs';
import {renderMarker} from '../../src/navigation/marker-recipe.mjs';
import {loadMarkerDescriptors,prepareContextMarkers} from '../../tools/prepare-navigation.mjs';
const baseline='bd265cf3a091c4ef17e9be76dfeb23410364884f';
const oldFile=execFileSync('git',['show',`${baseline}:site/prepared-navigation-markers.mjs`],{maxBuffer:10*1024*1024});
const old=JSON.parse(oldFile.toString().split('Object.freeze(')[1].split(');')[0]);
const added=JSON.parse(await readFile('output/trojan-population/bodies.json','utf8')).map(b=>b.id);
const planets=OBJECTS.toSorted((a,b)=>a.distanceAu-b.distanceAu);
const descriptors=await loadMarkerDescriptors({planets:planets.filter(b=>added.includes(b.id))});
const byId=new Map(descriptors.map(d=>[d.planetId,d]));
const output='output/trojan-population/navigation';await mkdir(output,{recursive:true});
const sha=b=>createHash('sha256').update(b).digest('hex');
const evidence={baseline,baselinePresentationSha256:sha(oldFile),atlases:[]};
for(const density of [1,2]){
 const tileSize=16*density,filename=`planet-markers${density===2?'@2x':''}.webp`;
 const original=execFileSync('git',['show',`${baseline}:public/navigation/${filename}`],{maxBuffer:5*1024*1024});
 const tiles=[];
 for(const [index,body] of planets.entries()){
  let input;
  if(byId.has(body.id)){
   const descriptor=byId.get(body.id);
   input=await renderMarker(descriptor,{sourcePath:resolve('src/planets',body.id,'source',descriptor.source.path),tileSize});
  }else{
   if(!old[body.id])throw new Error(`No pinned marker for ${body.id}`);
   input=await sharp(original).extract({left:old[body.id].index*tileSize,top:0,width:tileSize,height:tileSize}).png().toBuffer();
  }
  tiles.push({input,left:index*tileSize,top:0});
 }
 const raw=Buffer.alloc(planets.length*tileSize*tileSize*4);
 for(let i=0;i<tiles.length;i++){
  const tile=await sharp(tiles[i].input).ensureAlpha().raw().toBuffer();
  for(let y=0;y<tileSize;y++)tile.copy(raw,(y*planets.length*tileSize+i*tileSize)*4,y*tileSize*4,(y+1)*tileSize*4);
 }
 const bytes=await sharp(raw,{raw:{width:planets.length*tileSize,height:tileSize,channels:4}}).webp({lossless:true,effort:6}).toBuffer();
 const decoded=await sharp(bytes).ensureAlpha().raw().toBuffer();
 for(let i=0;i<tiles.length;i++){
  const expected=await sharp(tiles[i].input).ensureAlpha().raw().toBuffer();
  for(let y=0;y<tileSize;y++)for(let x=0;x<tileSize;x++){
   const a=(y*planets.length*tileSize+i*tileSize+x)*4,b=(y*tileSize+x)*4;
   if(decoded[a+3]!==expected[b+3]||(expected[b+3]!==0&&!decoded.subarray(a,a+3).equals(expected.subarray(b,b+3))))throw new Error('Visible marker pixels changed during packing');
  }
 }
 await writeFile(resolve('public/navigation',filename),bytes);
 evidence.atlases.push({filename,baselineSha256:sha(original),sha256:sha(bytes),bytes:bytes.length,retainedTiles:planets.length-added.length,newTiles:added.length,pixelEquality:true});
}
const context=await prepareContextMarkers({projectRoot:process.cwd(),outputRoot:resolve('public/navigation'),descriptors,planets});
const presentations=Object.fromEntries(planets.map((body,index)=>[body.id,{...(old[body.id]??{}),index,count:planets.length,...(byId.has(body.id)?{presentation:byId.get(body.id).presentation,context:context[body.id]}:{})}]));
await writeFile('site/prepared-navigation-markers.mjs','// Generated from object-owned marker recipes. Do not edit.\nexport const PREPARED_NAVIGATION_MARKERS = Object.freeze('+JSON.stringify(presentations)+');\n');
await writeFile(resolve(output,'evidence.json'),JSON.stringify(evidence,null,2)+'\n');
console.log(JSON.stringify(evidence));
