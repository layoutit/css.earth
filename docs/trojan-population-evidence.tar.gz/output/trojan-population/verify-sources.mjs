import {readFile,writeFile,mkdtemp,mkdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {resolve,join} from 'node:path';
import {verifySources,restoreMissingSources,assertSourceBytes} from '../../tools/objects/dist/operations.js';
const bodies=JSON.parse(await readFile('output/trojan-population/bodies.json'));
const root=await mkdtemp(join(tmpdir(),'cssearth-trojans-sources-')),reports=[];
// Identical shared input downloads are reused as bytes only after their first
// network restoration, while each empty per-object destination is hash-checked.
const downloads=new Map();
const transport={fetch:async(url,init)=>{
 const key=String(url);if(!downloads.has(key))downloads.set(key,(async()=>{const r=await fetch(url,init);if(!r.ok)throw new Error(`Download failed ${r.status}: ${url}`);return new Uint8Array(await r.arrayBuffer());})());
 return new Response(await downloads.get(key),{status:200});
}};
for(const {id} of bodies){
 const sourceRoot=resolve('src/planets',id,'source'),manifest=JSON.parse(await readFile(join(sourceRoot,'manifest.json'))),plan=JSON.parse(await readFile(join(sourceRoot,'preparation/acquisition.json')));
 const verified=await verifySources({sourceRoot,manifest});
 const target=join(root,id);await mkdir(target);
 const restored=await restoreMissingSources({sourceRoot:target,manifest,plan,missing:manifest.inputs.map(e=>e.path),transport});
 for(const entry of manifest.inputs)assertSourceBytes(entry,await readFile(join(target,entry.path)));
 reports.push({id,verified,restored,sourceRoot:target,inputs:manifest.inputs.map(({path,expectedBytes,expectedSha256})=>({path,expectedBytes,expectedSha256}))});
 console.log(id,'source closure and empty-destination restoration passed');
 await writeFile('output/trojan-population/source-restoration.json',JSON.stringify({root,distinctNetworkDownloads:downloads.size,reports},null,2)+'\n');
}
