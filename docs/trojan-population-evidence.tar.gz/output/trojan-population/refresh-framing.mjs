// Existing Lucy camera convention: frame the original source's outer radius.
// Existing scene epoch refresh updates metadata without raster/mesh preparation.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {refreshSolidSceneEpoch} from '../../tools/objects/terrestrial-layers/solid-scene.mjs';
import {prepareObjectJson,writeObjectJson} from '../../tools/prepare-object-json.mjs';
const read=async path=>JSON.parse(await readFile(path,'utf8'));
const write=(path,value)=>writeFile(path,JSON.stringify(value,null,2)+'\n');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const bodies=await read('output/trojan-population/bodies.json'),reports=[];
for(const body of bodies){
 const root=`src/planets/${body.id}`,path=`${root}/source/preparation/terrestrial.json`;
 const config=await read(path),outerRadiusKm=body.radialRangeSourceUnits[1]*body.scaleKmPerSourceUnit;
 const previousScale=config.geometry.camera.framingScale??1;
 config.geometry.camera.framingScale=Math.min(1,config.geometry.radiusKm/outerRadiusKm);
 await write(path,config);
 const bytes=await readFile(path),digest=sha(bytes);
 const manifest=await read(`${root}/source/manifest.json`);
 const document=manifest.documents.find(entry=>entry.path==='preparation/terrestrial.json');
 assert.ok(document);document.expectedBytes=bytes.length;document.expectedSha256=digest;
 await write(`${root}/source/manifest.json`,manifest);
 const descriptor=await read(`${root}/object.json`);
 descriptor.properties.recipe.sources.find(entry=>entry.id==='terrestrial').sha256=digest;
 await write(`${root}/object.json`,descriptor);
 const scene=await read(`${root}/prepared/scene.json`),definition=await read(`${root}/prepared/runtime.json`);
 const before={terrain:sha(await readFile(`${root}/prepared/terrain.json`)),assets:sha(await readFile(`${root}/runtime-assets.json`))};
 const updated=await refreshSolidSceneEpoch({config,scene,definition});
 assert.deepEqual(updated.scene.bodyLeaves,scene.bodyLeaves);
 await writeFile(`${root}/prepared/scene.json`,JSON.stringify(updated.scene));
 await write(`${root}/prepared/runtime.json`,updated.definition);
 await writeObjectJson(body.id,updated.definition);
 assert.equal(sha(await readFile(`${root}/prepared/terrain.json`)),before.terrain);
 assert.equal(sha(await readFile(`${root}/runtime-assets.json`)),before.assets);
 reports.push({id:body.id,previousScale,framingScale:config.geometry.camera.framingScale,referenceRadiusKm:config.geometry.radiusKm,originalOuterRadiusKm:outerRadiusKm,...before});
 console.log(body.id,'framing metadata refreshed; source geometry and image inventory unchanged');
}
await prepareObjectJson([]);
await write('output/trojan-population/framing.json',reports);
